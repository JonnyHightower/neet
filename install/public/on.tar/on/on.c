/*
 * on [-h <auth_host>] [-u <auth_uid>] [-g <auth_gid>] [-t <timeout>] [-m] [-i] [-v] <host> [<command> [<args>]]
 *
 * A rexd client.
 *
 * -h, -u and -g allow you to change your auth_unix credentials.
 * Default timeout is 5 seconds.
 * -m => pass a minimal (anonymous) environment across the wire rather than your own.
 * -i is interactive mode, anything you type on stdin will be sent to the rexd server.
 * -v turns on verbose mode, twice gives even more info.
 *
 * If no command and args are given "/bin/sh -i" and interactive mode are used.
 *
 * In interactive mode, EOF (^D) on stdin will terminate the connection.
 * SIGINT (^C) is passed to the command you're currently running on the server.
 * SIGTSTP (^Z) suspends the client rather than the command on the server.
 * As the rsh man page has always said...
 *    Stop signals stop the local rsh process only; this is arguably wrong, but
 *    currently hard to fix for reasons too complicated to explain here.
 * (REXPROC_SIGNAL only allows you to pass SIGINT.)
 *
 * Compile with: gcc -o on on.c -lrpcsvc
 * (Ignore warnings about rex.h redefining constants that are in termios.h.)
 *
 * Only tested on OpenBSD and Linux (against a Solaris ;-) rexd server).
 *
 * SiK (si.kay@bigfoot.com), 28/9/2000
 */

/*
TODO:
sort out tty modes stuff - you probably don't wanna use vi at the moment!
(the server thinks we're not on a tty for some reason)
*/

#include <sys/types.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <termios.h>
#include <rpc/rpc.h>
#include <rpcsvc/rex.h>

extern char **environ;

/* timeout value for RPC calls, in seconds */
#define DEFAULT_TIMEOUT	5

#define DEFAULT_NCMDS	2
#define DEFAULT_CMDS	{ "/bin/sh", "-i" }

#define MINIMAL_ENV	{ NULL,		/* space for "PS1=[on <host>]# " */			\
			  "HOME=/",								\
			  "PATH=/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin",	\
			  "TERM=vt100",								\
			  NULL }

#define REXPROTO	"tcp"

/* listen backlog */
#define BACKLOG		5

#ifndef TRUE
#define TRUE	1
#define FALSE	0
#endif

#ifndef MAX
#define MAX(a, b)	((a) > (b) ? (a) : (b))
#endif

/* prototypes */
void interactive_init(CLIENT *, int);

void handle_tty(int, int);
void write_all(int, const void *, size_t);

void sigint_handler(int);
void sigwinch_handler(int);

void call_rex_start(CLIENT *, int, char **, char **, int, int, int);
void call_rex_modes(CLIENT *, struct rex_ttymode *, int);
void call_rex_winch(CLIENT *, int, int, int);
void call_rex_signal(CLIENT *, int, int);

void usage(char *);
void fatal(char *, ...);

/* bloody parameterless signal handlers */
CLIENT *sig_rex_clnt;
int sig_timeout;

int
main(int argc, char *argv[])
{
	int arg;
	char auth_host[MAXHOSTNAMELEN];
	uid_t auth_uid;
	gid_t auth_gid;
	int interactive;
	int verbose;
	char *server;
	char *default_cmds[] = DEFAULT_CMDS;
	char **commands;
	int ncmds;
	int timeout;
	char *minimal_env[] = MINIMAL_ENV;
	char ps1[MAXHOSTNAMELEN + 16];
	char **env;
	AUTH *auth;
	CLIENT *rex_clnt;
	int ttyport;
	int ttysock;
	struct sockaddr_in ttyaddr;
	socklen_t ttyaddr_len;
	int sockopt;
	int i;

	if(gethostname(auth_host, MAXHOSTNAMELEN) < 0)
		fatal("gethostname: %s\n", strerror(errno));

	auth_uid = getuid();
	auth_gid = getgid();
	env = NULL;
	interactive = FALSE;
	verbose = 0;
	timeout = DEFAULT_TIMEOUT;

	opterr = 0;
	/* need '+' so glibc does the posix thing and stops when it gets to <host> */
	while((arg = getopt(argc, argv, "+h:u:g:t:miv")) != EOF)
	{
		switch(arg)
		{
		case 'h':
			strncpy(auth_host, optarg, MAXHOSTNAMELEN);
			break;

		case 'u':
			auth_uid = atoi(optarg);
			break;

		case 'g':
			auth_gid = atoi(optarg);
			break;

		case 't':
			timeout = atoi(optarg);
			break;

		case 'm':
			env = minimal_env;
			break;

		case 'i':
			interactive = TRUE;
			break;

		case 'v':
			verbose ++;
			break;

		default:
			usage(argv[0]);
			break;
		}
	}

	if(optind > argc - 1)
		usage(argv[0]);
				 
	server = argv[optind];

	ncmds = argc - (optind + 1);
	if(ncmds > 0)
	{
		commands = &argv[optind + 1];
	}
	else
	{
		ncmds = DEFAULT_NCMDS;
		commands = default_cmds;
		interactive = TRUE;
	}

	/* make sure the user realises it's worked */
	snprintf(ps1, sizeof(ps1), "PS1=[on %s]%c ", server, (auth_uid ? '$' : '#'));
	if(env == minimal_env)
	{
		env[0] = ps1;
	}
	else
	{
		putenv(ps1);
		env = environ;
	}

	if((auth = authunix_create(auth_host, auth_uid, auth_gid, 0, NULL)) == NULL)
		fatal("authunix_create failed\n");

	if(verbose > 0)
		printf("Credentials: host=%s uid=%d gid=%d\n", auth_host, auth_uid, auth_gid);

	if(verbose > 1)
	{
		printf("Commands (%d):", ncmds);
		for(i=0; i<ncmds; i++)
			printf(" %s", commands[i]);
		printf("\n");
		printf("Environment:\n");
		for(i=0; env[i]; i++)
			printf("%s\n", env[i]);
	}

	if((rex_clnt = clnt_create(server, REXPROG, REXVERS, REXPROTO)) == NULL)
		fatal(clnt_spcreateerror("clnt_create"));
	rex_clnt->cl_auth = auth;

	/* create a socket to listen for replies */
	if((ttysock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		fatal("socket: %s\n", strerror(errno));

	/* in case someones already using it */
	sockopt = 1;
	if(setsockopt(ttysock, SOL_SOCKET, SO_REUSEADDR, &sockopt, sizeof(sockopt)) < 0)
		fatal("setsockopt: SO_REUSEADDR: %s\n", strerror(errno));

	memset(&ttyaddr, 0, sizeof(ttyaddr));
	ttyaddr.sin_family = AF_INET;
	ttyaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	ttyaddr.sin_port = 0;

	if(bind(ttysock, (struct sockaddr *) &ttyaddr, sizeof(ttyaddr)) < 0)
		fatal("bind: %s\n", strerror(errno));

	/* see which port the kernel gave us */
	ttyaddr_len = sizeof(ttyaddr);
	if(getsockname(ttysock, (struct sockaddr *) &ttyaddr, &ttyaddr_len) < 0)
		fatal("getsockname: %s\n", strerror(errno));
	ttyport = ntohs(ttyaddr.sin_port);

	if(verbose > 1)
		printf("Local port: %d\n", ttyport);

	if(listen(ttysock, BACKLOG) < 0)
		fatal("listen: %s\n", strerror(errno));

	if(interactive)
		interactive_init(rex_clnt, timeout);

	/* call the rexd server to exec the command */
	call_rex_start(rex_clnt, ncmds, commands, env, interactive, ttyport, timeout);

	/* copy in/out/err data between us and the rexd server */
	handle_tty(ttysock, interactive);

	clnt_destroy(rex_clnt);

	return EXIT_SUCCESS;
}

void
interactive_init(CLIENT *rex_clnt, int timeout)
{
	struct sigaction action;
	struct rex_ttymode rexinfo;
	struct termios terminfo;
	struct winsize termsize;

	/* why can't you pass params to signal handlers? */
	sig_rex_clnt = rex_clnt;
	sig_timeout = timeout;

	/* set signal handlers to pass on SIGINT and SIGWINCH */
	action.sa_handler = sigint_handler;
	sigemptyset(&action.sa_mask);
	action.sa_flags = 0;
	if(sigaction(SIGINT, &action, NULL) < 0)
		fatal("signal: SIGINT: %s\n", strerror(errno));

	action.sa_handler = sigwinch_handler;
	if(sigaction(SIGWINCH, &action, NULL) < 0)
		fatal("signal: SIGWINCH: %s\n", strerror(errno));

#if 0
/* sadly, this doesn't work - the server just ignores us (cuz we're not on a tty?) */
	/* ignore SIGTSTP so the key press goes to the rexd server */
	action.sa_handler = SIG_IGN;
	if(sigaction(SIGTSTP, &action, NULL) < 0)
		fatal("signal: SIGTSTP: %s\n", strerror(errno));
#endif

	/* send the current terminal settings */
	memset(&rexinfo, 0, sizeof(rexinfo));
	if(tcgetattr(fileno(stdin), &terminfo) < 0)
		fatal("tcgetattr: %s\n", strerror(errno));
	rexinfo.basic.four = 4;
	rexinfo.basic.chars[0] = cfgetispeed(&terminfo);
	rexinfo.basic.chars[1] = cfgetospeed(&terminfo);
	rexinfo.basic.chars[2] = terminfo.c_cc[VKILL];
	rexinfo.basic.chars[3] = terminfo.c_cc[VERASE];
	/* rexinfo.basic.flags = ? */
	rexinfo.more.six = 6;
	rexinfo.more.chars[0] = terminfo.c_cc[VINTR];
	rexinfo.more.chars[1] = terminfo.c_cc[VQUIT];
	rexinfo.more.chars[2] = terminfo.c_cc[VSTART];
	rexinfo.more.chars[3] = terminfo.c_cc[VSTOP];
	rexinfo.more.chars[4] = terminfo.c_cc[VEOF];
	rexinfo.more.chars[5] = '\n';	/* there's no VNL, is this VEOL? */
	rexinfo.yetmore.six = 6;
	rexinfo.yetmore.chars[0] = terminfo.c_cc[VSUSP];
#ifdef VDSUSP	/* Linux doesn't have this, though it does define CDSUSP */
	rexinfo.yetmore.chars[1] = terminfo.c_cc[VDSUSP];
#endif
	rexinfo.yetmore.chars[2] = terminfo.c_cc[VREPRINT];
	/* rexinfo.yetmore.chars[3] = flush output */
	rexinfo.yetmore.chars[4] = terminfo.c_cc[VWERASE];
	rexinfo.yetmore.chars[5] = terminfo.c_cc[VLNEXT];
	/* rexinfo.yetmore.mode = ? */
	/* rexinfo.andmore = ? */
	call_rex_modes(rex_clnt, &rexinfo, timeout);

	/* send the current terminal size */
	if(ioctl(fileno(stdin), TIOCGWINSZ, &termsize) < 0)
		fatal("ioctl: TIOCGWINSZ: %s\n", strerror(errno));
	call_rex_winch(rex_clnt, termsize.ws_row, termsize.ws_col, timeout);

	return;
}

#define BUFF_LEN	1024

void
handle_tty(int ttysock, int interactive)
{
	struct sockaddr_in rexaddr;
	socklen_t addrlen;
	int rexsock;
	int insock;
	int maxsock;
	fd_set read_fds;
	int nready;
	char buff[BUFF_LEN];
	int nbytes;
	int done;

	addrlen = sizeof(rexaddr);
	if((rexsock = accept(ttysock, (struct sockaddr *) &rexaddr, &addrlen)) < 0)
		fatal("accept: %s\n", strerror(errno));

	/* don't need to listen for new connections anymore */
	close(ttysock);

	insock = fileno(stdin);
	maxsock = MAX(rexsock, insock) + 1;

	done = FALSE;
	while(!done)
	{
		FD_ZERO(&read_fds);
		FD_SET(rexsock, &read_fds);
		if(interactive)
			FD_SET(insock, &read_fds);
		nready = select(maxsock, &read_fds, NULL, NULL, NULL);
		if(nready < 0 && errno != EINTR)
			fatal("select: %s\n", strerror(errno));
		if(FD_ISSET(rexsock, &read_fds))
		{
			nbytes = read(rexsock, buff, BUFF_LEN);
			if(nbytes < 0 && errno != EINTR && errno != EAGAIN)
				fatal("read rexd: %s\n", strerror(errno));
			else if(nbytes > 0)
				write_all(fileno(stdout), buff, nbytes);
			else if(nbytes == 0)	/* EOF */
				done = TRUE;
		}
		if(FD_ISSET(insock, &read_fds))
		{
			nbytes = read(insock, buff, BUFF_LEN);
			if(nbytes < 0 && errno != EINTR && errno != EAGAIN)
				fatal("read stdin: %s\n", strerror(errno));
			else if(nbytes > 0)
				write_all(rexsock, buff, nbytes);
			/* ignore EOF on stdin? */
			else if(nbytes == 0)	/* EOF */
				done = TRUE;
		}
	}

	return;
}

void
write_all(int fd, const void *buf, size_t count)
{
	size_t nwritten;
	const char *buf_ptr;

	buf_ptr = buf;
	while(count > 0)
	{
		if((nwritten = write(fd, buf_ptr, count)) < 0)
		{
			if(errno == EINTR)
				nwritten = 0;
			else
				fatal("write: %s\n", strerror(errno));
		}
		count -= nwritten;
		buf_ptr += nwritten;
	}

	return;
}

void
sigint_handler(int sig_num)
{
	call_rex_signal(sig_rex_clnt, sig_num, sig_timeout);

	return;
}

void
sigwinch_handler(int sig_num)
{
	struct winsize termsize;

	if(ioctl(fileno(stdin), TIOCGWINSZ, &termsize) < 0)
		fatal("ioctl: TIOCGWINSZ: %s\n", strerror(errno));
	call_rex_winch(sig_rex_clnt, termsize.ws_row, termsize.ws_col, sig_timeout);

	return;
}

void
call_rex_start(CLIENT *rex_clnt, int ncmds, char **commands, char **env, int interactive, int ttyport, int max_secs)
{
	struct timeval timeout;
	struct rex_start args;
	struct rex_result result;
	int env_len;

	timeout.tv_sec = max_secs;
	timeout.tv_usec = 0;

	memset(&args, 0, sizeof(args));
	memset(&result, 0, sizeof(result));

	/* array of commands */
	args.rst_cmd.rst_cmd_len = ncmds;
	args.rst_cmd.rst_cmd_val = commands;

	/* working directory - what should this be? */
	args.rst_host = "";
	args.rst_fsname = "";
	args.rst_dirwithin = "";

	/* array of environment vars */
	for(env_len=0; env[env_len]; env_len ++);
	args.rst_env.rst_env_len = env_len;
	args.rst_env.rst_env_val = env;

	args.rst_port0 = ttyport;
	args.rst_port1 = ttyport;
	args.rst_port2 = ttyport;

#if 0
/* God knows what this flag is for, but if you set it the server doesn't execute the command you send! */
	/* flags */
	if(interactive)
		args.rst_flags = REX_INTERACTIVE;
#endif

	if(clnt_call(rex_clnt, REXPROC_START,
	      	     (xdrproc_t) xdr_rex_start, (caddr_t) &args,
		     (xdrproc_t) xdr_rex_result, (caddr_t) &result,
		     timeout) != RPC_SUCCESS)
		fatal(clnt_sperror(rex_clnt, "clnt_call: REXPROC_START"));

	if(result.rlt_stat != 0)
		fatal("REXPROC_START: %s\n", result.rlt_message);

	if(!clnt_freeres(rex_clnt, (xdrproc_t) xdr_rex_result, (caddr_t) &result))
	       fatal("REXPROC_START: clnt_freeres: can't free memory\n");	

	return;
}

void
call_rex_modes(CLIENT *rex_clnt, struct rex_ttymode *args, int max_secs)
{
	struct timeval timeout;

	timeout.tv_sec = max_secs;
	timeout.tv_usec = 0;

	/* remember args is a ptr here */
	if(clnt_call(rex_clnt, REXPROC_MODES,
	      	     (xdrproc_t) xdr_rex_ttymode, (caddr_t) args,
		     (xdrproc_t) xdr_void, NULL,
		     timeout) != RPC_SUCCESS)
		fatal(clnt_sperror(rex_clnt, "clnt_call: REXPROC_MODES"));

	/* is this needed? */
	if(!clnt_freeres(rex_clnt, (xdrproc_t) xdr_void, NULL))
	       fatal("REXPROC_MODES: clnt_freeres: can't free memory\n");	

	return;
}

void
call_rex_winch(CLIENT *rex_clnt, int rows, int cols, int max_secs)
{
	struct timeval timeout;
	struct rex_ttysize args;

	timeout.tv_sec = max_secs;
	timeout.tv_usec = 0;

	memset(&args, 0, sizeof(args));

	args.ts_lines = rows;
	args.ts_cols = cols;

	if(clnt_call(rex_clnt, REXPROC_WINCH,
	      	     (xdrproc_t) xdr_rex_ttysize, (caddr_t) &args,
		     (xdrproc_t) xdr_void, NULL,
		     timeout) != RPC_SUCCESS)
		fatal(clnt_sperror(rex_clnt, "clnt_call: REXPROC_WINCH"));

	/* is this needed? */
	if(!clnt_freeres(rex_clnt, (xdrproc_t) xdr_void, NULL))
	       fatal("REXPROC_WINCH: clnt_freeres: can't free memory\n");	

	return;
}

void
call_rex_signal(CLIENT *rex_clnt, int sig_num, int max_secs)
{
	struct timeval timeout;
	int args;

	timeout.tv_sec = max_secs;
	timeout.tv_usec = 0;

	args = sig_num;

	if(clnt_call(rex_clnt, REXPROC_SIGNAL,
	      	     (xdrproc_t) xdr_int, (caddr_t) &args,
		     (xdrproc_t) xdr_void, NULL,
		     timeout) != RPC_SUCCESS)
		fatal(clnt_sperror(rex_clnt, "clnt_call: REXPROC_SIGNAL"));

	/* is this needed? */
	if(!clnt_freeres(rex_clnt, (xdrproc_t) xdr_void, NULL))
	       fatal("REXPROC_SIGNAL: clnt_freeres: can't free memory\n");	

	return;
}

void
usage(char *prog_name)
{
	fatal("Usage: %s [-h <auth_host>] [-u <auth_uid>] [-g <auth_gid>] "
			"[-t <timeout>] [-m] [-i] [-v] "
			"<host> [<command> [<args>]]\n", prog_name);
}

void
fatal(char *error, ...)
{
	va_list args;

	va_start(args, error);

	vfprintf(stderr, error, args);

	va_end(args);

	exit(EXIT_FAILURE);
}
