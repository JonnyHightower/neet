This is the library "libopenvashg", formerly known as "libopenvas_hg".

The contained code is a remainder from the free Nessus times.

As decided in Change Request #38 (http://openvas.org/openvas-cr-38.html) it
remains here as is until consolidated into another library or resolved in
another way.

New, clean code should go into the openvas-libraries/base directory (or any
other directory as described in the Change Request).
