This is the library "libopenvas_nasl", formerly known as standalone module
"libnasl".

See the file ChangeLog-pre-09-2009 for ChangeLog entries before 01-09-2009.
