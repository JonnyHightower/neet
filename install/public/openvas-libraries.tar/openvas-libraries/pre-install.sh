#!/bin/bash

type cmake >/dev/null 2>&1

if [ $? -eq 1 ]; then
	echo "Can't build this package - cmake is not installed!"
	exit 1
fi

cmake .

# Nasty incompatibility between this version of openvas-nasl and GCC-4.6.
# Kludge for letting openvas build for now....
for file in `grep -R -l Werror * | grep -v pre-install.sh`; do
	sed -e 's/-Werror //g' -i $file;
done

make
make install

exit $?

