#!/bin/sh
#
# Wrapper for OracleQuery by patrik@cqure.net
# Wrapped for neet by Jonathan Roach
#
BASE=__MORIARTY__
OWD="$PWD"
cd "$BASE"
JAVA=java
JDBC=classes12.jar
$JAVA -cp .:$JDBC:ork.jar ork.OracleQuery $*
cd "$OWD"
