package ork;

import java.sql.*;
import java.io.*;

public class FmtResultSet {

    private ResultSet m_oRS = null;
    private int m_nColumns = -1;
    private String m_sDelimiter = " | ";

    public FmtResultSet( ResultSet oRS ) {
	m_oRS = oRS;
    }

    public void setDelimiter(String sDelimiter) {

	if ( sDelimiter != null && sDelimiter.length() > 0 )
	    m_sDelimiter = sDelimiter;

    }

    public void close() {

	try {
	    if ( m_oRS != null )
		m_oRS.close();

	    m_oRS = null;
	}
	catch( SQLException e ) {
	    e.printStackTrace();
	}

    }

    public void outputHeaders(PrintStream oPS) {

	String sHeader = "";

	if ( m_oRS != null ) {

	    try {

		ResultSetMetaData oRSMD = m_oRS.getMetaData();
		m_nColumns = oRSMD.getColumnCount();
		
		for ( int nColumn = 1; nColumn <= m_nColumns; nColumn ++ ) {
		    sHeader += oRSMD.getColumnName(nColumn);

		    /* only add delimiter if it is not the last column */
		    if ( nColumn != m_nColumns )
			sHeader += m_sDelimiter;
		}
		
		oPS.println( sHeader );

	    }
	    catch ( SQLException e ) {
		e.printStackTrace();
	    }
	    
	}

    }


    public void outputData(PrintStream oPS) {

	if ( m_oRS == null )
	    return;

	try {

	    while ( m_oRS.next() ) {
		for ( int i = 1; i <= m_nColumns; i++ ) {
		    oPS.print( m_oRS.getString(i) );

		    if ( i != m_nColumns )
			oPS.print( m_sDelimiter );

		}

		oPS.println();
	    }

	}
	catch ( SQLException e ) {
	    e.printStackTrace();
	}

    }

}
