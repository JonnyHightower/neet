/**
 * Utility.java
 * Copyright (c) 1998 Gaurang Hirpara
 * @version 1.0 - February 1998
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 */

package tftp;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.SocketException;

public class Utility 
{

    public static void sendPacket (InetAddress destAddr,
				   int sourcePort,
				   int destPort,
				   int opcode,
				   int blockNumber,
				   byte[] data,
				   DatagramSocket inSock)
    {
        int refSize;
	byte[] rv;
	DatagramSocket ds;
	DatagramPacket dp;

	if (data == null && opcode == ERR_PACKET 
	     && (blockNumber >= 0 && blockNumber < 8)) {
	  data = errStrings[blockNumber].getBytes();
	}


	if (data != null) {
	  refSize = data.length;
	} else {
	  refSize = 0;
	}

	/*System.err.println ("SEND " 
			    + (OpString[opcode]) 
			    + " [" 
			    + sourcePort
			    + ","
			    + destPort
			    + "] BN=[" + blockNumber + "]");*/
				    
	switch (opcode) {
	    case DATA_PACKET:
		rv = new byte[refSize + 4];
		break;
	    case ACK_PACKET:
		rv = new byte[4];
		break;
	    case ERR_PACKET:
	        rv = new byte[refSize + 5];
		break;
	    default:
	    case RRQ_PACKET:
	    case WRQ_PACKET:
	        rv = null;
	}

	if (rv == null) return;

	rv[0] = (byte)((opcode >> 8) & 0xff);
	rv[1] = (byte)(opcode & 0xff);
	rv[2] = (byte)((blockNumber >> 8) & 0xff);
	rv[3] = (byte)(blockNumber & 0xff);
	
	switch (opcode) {
	    case RRQ_PACKET:
		rv = null;
		break;
	    case WRQ_PACKET:
		rv = null;
		break;
	    case DATA_PACKET:
		for (int i = 0; i < refSize; i++) {
		    rv[4 + i] = data[i];
		}
		break;
	    case ACK_PACKET:
		break;
	    case ERR_PACKET:
		for (int i = 0; i < refSize; i++) {
		    rv[4 + i] = data[i];
		}
		rv[rv.length - 1] = 0;
		break;
	}

	try {
  	    if (inSock == null) {
	      ds = new DatagramSocket (sourcePort);
	    } else {
	      ds = inSock;
	    }
	    dp = new DatagramPacket (rv, rv.length,
				     destAddr,
				     destPort);
	    ds.send (dp);
	    if (inSock == null) {
	      ds.close();
	      ds = null;
	    }
	} catch (Exception e1) {
	    e1.printStackTrace();
	} 
    }
  
    public static void receive(DatagramSocket rec, 
			       DatagramPacket pack)
       throws InterruptedIOException, IOException
    {
	rec.receive (pack);

	/*System.err.println ("RECV " 
			    + (OpString[fetchOpcode(pack.getData())]) 
			    + " [" 
			    + (rec.getLocalPort())
			    + ","
			    + (pack.getPort())
			    + "] BN=[" 
			    + (fetchBlockNumber(pack.getData()))
			    + "]");*/
    }

    public static int fetchOpcode(byte[] data)
    {
        return ((data[0] << 8 | data[1]) & 0xffff);
    }

    public static int fetchBlockNumber(byte[] data)
    {
      return (((int)((int)data[2] << 8) & 0xff00) 
	      | ((int)data[3] & 0xff));
    }

    public static String fetchErrorMessage(int messageID, String defaultMsg)
    {
      if (messageID > ERR_NOT_DEFINED 
	  && messageID <= ERR_NO_SUCH_USER) {
	return errStrings [messageID];
      } else {
	return defaultMsg;
      }
    }

    public static String fetchErrorMessage(byte[] data)
    {
      StringBuffer rv = new StringBuffer();
      for (int i = 4; i < data.length; i++) {
	if (data[i] == 0) break;
	rv.append ((char)data[i]);
      }
      return rv.toString();
    }

    public static String getIP(InetAddress in)
    { 
      String ret;
      byte[] buf = in.getAddress();
      StringBuffer rv = new StringBuffer();
      for (int i = 0; i < buf.length; i++) {
	rv.append (buf[i] + ".");
      }
      ret = rv.toString();
      return ret.substring (0, ret.length() - 1);
    }

    public final static int RRQ_PACKET  = 1;
    public final static int WRQ_PACKET  = 2;
    public final static int DATA_PACKET = 3;
    public final static int ACK_PACKET  = 4;
    public final static int ERR_PACKET  = 5;

    public final static int ERR_NO_ERROR         = -1;
    public final static int ERR_NOT_DEFINED      = 0;
    public final static int ERR_FILE_NOT_FOUND   = 1;
    public final static int ERR_ACCESS_VIOLATION = 2;
    public final static int ERR_DISK_FULL        = 3;
    public final static int ERR_ILLEGAL_OP       = 4;
    public final static int ERR_UNKNOWN_TRANS_ID = 5;
    public final static int ERR_FILE_EXISTS      = 6;
    public final static int ERR_NO_SUCH_USER     = 7;

    public final static int ASCII_MODE  = 1;
    public final static int OCTET_MODE  = 2;
    public final static int UNKNOWN_MODE= 3;

    public final static int BLOCK_SIZE  = 512;


    public final static int BEGIN       = 1;
    public final static int RUNT_PACKET = 2;
    public final static int COMPLETE    = 10;

  static String[] errStrings = {"Unknown error",
				"File not found",
				"Access violation",
				"Disk full or allocation exceeded",
				"Illegal TFTP operation",
				"Unknown transfer ID",
				"File already exists",
				"No such user"};

  static String[] OpString = {"---",
			      "RRQ",
			      "WRQ",
			      "DAT",
			      "ACK",
			      "ERR"};

}
