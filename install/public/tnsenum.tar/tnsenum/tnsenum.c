#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
//#include <net/if.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include "tns_packet.h"
#define MAX_PORTS 65535
#define WAIT_TIME 5
#define MAX_RECV_BUF_SIZE 100000
#ifndef IPPROTO_TCP
#define IPPROTO_TCP 6
#endif
void usage(char *name)
{
	printf("Usage: %s -p <portlist> <host>\n",name);
	exit(0);
}

int readnum(char *portstring, int *i)
{
char portnum[6],c;
int j=0;
	while ((isdigit(portstring[*i])!=0)&&(j<6))
	{
		portnum[j]=portstring[*i];
		j++;(*i)++;
	}
	if ((portstring[*i]!='\0')&&(portstring[*i]!=',')&&(portstring[*i]!='-'))
		return 0;
	else
	{
		portnum[j]='\0';
		return atoi(portnum);
	}
}

int parseports(char *portstring,int ports[MAX_PORTS])
{
int i=0,j=0,k=0,count;
char c;
	while (portstring[i]!='\0')
	{
		j=readnum(portstring,&i);
		if (j!=0)
		{
			ports[k]=j;k++;
		}
		else
		{
			printf("Fatal Error: Invalid port specification\n");exit(0);
		}
		if (i!=strlen(portstring))
		{
			if (portstring[i]=='-')
			{
				i++;
				j=readnum(portstring,&i);
				if (j!=0)
				{
					for (count=ports[k-1];count<=j;count++)
					{ ports[k]=count;k++;}
				}
				else
				{
					printf("Fatal Error: Invalid port specification\n");exit(0);
				}
			}
			else if (portstring[i]==',') i++;
			else
			{
				printf("Fatal Error: Invalid port specification\n");exit(0);
			}
			
		}
	}
	return k;
}

void do_tns(int tcp_sock)
{
char *connect_data="(DESCRIPTION=(CONNECT_DATA=(CID=(PROGRAM=)(HOST=)(USER=xxxxxxxx))(COMMAND=status)(ARGUMENTS=64)(SERVICE=REMOTE)(VERSION=135294976)))";
void *buf,*pktbuf,*recvbuf,*databuf=NULL;
struct tns_packet_header the_header;
struct tns_connect_packet the_connect_packet;
struct tns_accept_packet the_accept_packet;
struct tns_data_packet the_data_packet;
struct timeval tv,tv2;
int recv_len,count,i,retval;
fd_set rfds;

	the_header.pkt_len=htons(184);
	the_header.pkt_chksum=0;
	the_header.pkt_type=1;
	the_header.reserved=0;
	the_header.hdr_chksum=0;
	
	the_connect_packet.version=htons(309);
	the_connect_packet.version_compat=htons(300);
	the_connect_packet.svc_options=0;
	the_connect_packet.SDUS=htons(4096);
	the_connect_packet.MTDUS=htons(32767);
	the_connect_packet.NTPC=htons(0x8308);
	the_connect_packet.LTV=0;
	the_connect_packet.Vof1inH=htons(0x0100);
	the_connect_packet.LCD=htons(132);
	the_connect_packet.OCD=htons(52);
	the_connect_packet.MRCD=htonl(134217728);
	the_connect_packet.CF0=1;
	the_connect_packet.CF1=1;
	the_connect_packet.TCFI1=0;
	the_connect_packet.TCFI2=0;
	the_connect_packet.TUCI=0;
	buf=(void *)malloc(132);
	memcpy(buf,connect_data,132);
	pktbuf=(void *)malloc(184);
	memcpy(pktbuf,&the_header,sizeof(the_header));
	memcpy(pktbuf+sizeof(the_header),&the_connect_packet,sizeof(the_connect_packet));
	memcpy(pktbuf+sizeof(the_header)+sizeof(the_connect_packet)+12,buf,132);
	if (send(tcp_sock,pktbuf,184,0)==-1)
	{
		perror("Error sending connect packet ");exit(0);
	}
	recvbuf=(void *)malloc(MAX_RECV_BUF_SIZE);
	memset(recvbuf,0,MAX_RECV_BUF_SIZE);
	tv.tv_sec=WAIT_TIME;
	tv.tv_usec=0;
	FD_ZERO(&rfds);
	FD_SET(tcp_sock,&rfds);
	retval=select(tcp_sock+1,&rfds,NULL,NULL,&tv);
	if (retval)
	{
		recv_len=recv(tcp_sock,recvbuf,MAX_RECV_BUF_SIZE,0);
		if (recv_len>0)
		{
			if (recv_len==24)
			{
				memcpy(&the_header,recvbuf,sizeof(struct tns_packet_header));
				if (ntohs(the_header.pkt_len)==24)
				{
					if (the_header.pkt_type==2)
					{
					// We have a TNS accept packet
						printf("Got TNS Accept packet\n");
						memset(recvbuf,0,MAX_RECV_BUF_SIZE);
						tv.tv_sec=WAIT_TIME; tv.tv_usec=0;
						retval=select(tcp_sock+1,&rfds,NULL,NULL,&tv);
						if (retval)
						{
							recv_len=recv(tcp_sock,recvbuf,MAX_RECV_BUF_SIZE,0);
							if (recv_len>0)
							{
								count=sizeof(the_header)+2;
								if (recv_len>count)
								{
									databuf=(void*)malloc(recv_len-count);
									memcpy(databuf,recvbuf+count,recv_len-count);
									for (i=0;i<recv_len-count;i++)
										if (isprint(((char *)databuf)[i])==0) {if (i>10) ((char *)databuf)[i]=' '; else break;}
									if (i!=0)
									{
										printf("Got TNS data.\n");
										realloc(databuf,i+1);
										((char *)databuf)[i]='\0';
										printf("%s\n",(char *)databuf);
									}
								}
								else {printf("Invalid data packet\n");}
							}
							else printf("No Data packet\n");
						}	
						memset(recvbuf,0,MAX_RECV_BUF_SIZE);
						tv.tv_sec=WAIT_TIME; tv.tv_usec=0;
						retval=select(tcp_sock+1,&rfds,NULL,NULL,&tv);
						if (retval)
						{
							recv_len=recv(tcp_sock,recvbuf,MAX_RECV_BUF_SIZE,0);
							if (recv_len>0)
							{
								count=sizeof(the_header)+2;
								if (recv_len>count)
								{
									databuf=(void*)malloc(recv_len-count);
									memcpy(databuf,recvbuf+count,recv_len-count);
									for (i=0;i<recv_len-count;i++)
										if (isprint(((char *)databuf)[i])==0) {if (i>10) ((char *)databuf)[i]=' '; else break;}
									if (i!=0)
									{
										printf("Got TNS data.\n");
										realloc(databuf,i+1);
										((char *)databuf)[i]='\0';
										printf("%s\n",(char *)databuf);
									}
								}
								else {printf("Invalid data packet\n");}
							}
							else printf("No Data packet\n");
						}	
					}
					else printf("Don't think this is a TNS Port\n");
				}
				else printf("Don't think this is a TNS Port\n");
			}
			else // Maybe we have data?
			{
				if (recv_len>(sizeof(the_header)+sizeof(the_accept_packet)))
				{
					memcpy(&the_header,recvbuf,sizeof(the_header));
					if(ntohs(the_header.pkt_len)==recv_len)
					{
					// Looking good
					        if (the_header.pkt_type==4)
						{
							printf("Got TNS refuse packet.\n");
							count=recv_len-sizeof(the_header)-4;
							databuf=(void *)malloc(count);
							memcpy(databuf,recvbuf+sizeof(the_header)+4,count);
						}
						else if (the_header.pkt_type==6) 
						{
							printf("Got TNS data packet.\n");
							count=recv_len-sizeof(the_header)-2;
							databuf=(void *)malloc(count);
							memcpy(databuf,recvbuf+sizeof(the_header)+2,count);
						}
						else {printf("Unknown packet type\n");}
						if (databuf!=NULL){
							for (i=0;i<count;i++)
								if (isprint(((char *)databuf)[i])==0) break;
							if (i==count)
							{
								realloc(databuf,count+1);
								((char *)databuf)[count]='\0';
								printf("%s\n",(char *)databuf);
							}
							free(databuf);
						}
						
					}
					else printf("Don't think this is a TNS port.\n");
				}
				else printf("Don't think this is a TNS port.\n");
			}
		}
		else printf("No packets recieved.\n");
	}
	free(buf);free(recvbuf);free(pktbuf);
}

int main(int argc, char *argv[])
{
int ports[MAX_PORTS],got_ports=0;
int arg,count;
struct hostent *he;
struct in_addr dstip;
struct sockaddr_in dst_addr;
int tcp_sock;
	memset(ports,0,MAX_PORTS);
	while ((arg=getopt(argc,argv,"p:")) != EOF)
	{
		switch(arg)
		{
		case 'p':
			got_ports=parseports(optarg,ports);
			printf("Got %d ports\n",got_ports);
			break;
		default:
			usage(argv[0]);
			break;
		}
	}
	if (got_ports==0) usage(argv[0]);
	if (optind != argc-1) usage(argv[0]);
	if (((he=gethostbyname(argv[optind]))!=NULL)&&(he->h_addrtype==AF_INET))
	{
		printf("Address ok\n");
		memcpy(&dstip,he->h_addr,sizeof(struct in_addr));
	}
	else
	{
		printf("Bad address\n");
		exit(0);
	}
	for (count=0;count<got_ports;count++)
	{
		tcp_sock=socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
		dst_addr.sin_family=PF_INET;
		dst_addr.sin_port=htons(ports[count]);
		memcpy(&dst_addr.sin_addr,&dstip,sizeof(struct in_addr));
		if(connect(tcp_sock,(const struct sockaddr *)&dst_addr,sizeof(dst_addr))<0)
		{
			printf("Port %d closed\n",ports[count]);
		}
		else
		{
			printf("Port %d open\n",ports[count]);
			do_tns(tcp_sock);
		}
		close(tcp_sock);
	}
	return 0;
}
