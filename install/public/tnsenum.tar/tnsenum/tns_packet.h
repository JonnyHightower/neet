struct tns_packet_header
{
u_int16_t pkt_len;
u_int16_t pkt_chksum;
u_char	  pkt_type;
u_char	  reserved;
u_int16_t hdr_chksum;
};

struct tns_connect_packet
{
u_int16_t version;
u_int16_t version_compat;
u_int16_t svc_options;
u_int16_t SDUS;
u_int16_t MTDUS;
u_int16_t NTPC;
u_int16_t LTV;
u_int16_t Vof1inH;
u_int16_t LCD;
u_int16_t OCD;
u_int32_t MRCD;
u_char	  CF0;
u_char	  CF1;
u_int16_t TCFI1;
u_int16_t TCFI2;
u_int16_t TUCI;
};

struct tns_accept_packet
{
u_int16_t version;
u_int16_t svc_options;
u_int16_t MTDUS;
u_int16_t Vof1inH;
u_int16_t acc_data_len;
u_int16_t off_to_acc_data;
u_char	  CF0;
u_char	  CF1;
};

struct tns_data_packet
{
u_int16_t data_flag;
void	 *data;
};
