#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

#define VERSION "v0.2"
#define TIMEOUT_SEC 5
#define MAX_PACKETS 5
#define BUFFER_SIZE 1024
#define TCP_CONNECT_STRING "GET / HTTP/1.0\r\n\r\nHELP\r\nQUIT\r\n"
 

void printPacket (unsigned char* pkt, unsigned long size) ;
int getval (char char_in) ;
int processString (const char* string_in, char** string_out);

void usage (char* programName)
{
   printf("Usage: %s [-t <timeout>] <host> <port>\n",programName);
   exit(1);
}

void connectTimeout()
{
#ifdef DEBUG
   printf ("Connection failed\n");
#endif
   exit(1);
}

int main (int argc, char *argv[]) 
{

  int SERVER_PORT ;
  int tcp_socket, result, i, count, packet_count = 0;
  struct sockaddr_in localAddr, servAddr;
  struct hostent *h;
  unsigned char buffer[BUFFER_SIZE + 1] ;
  char *connect_string ;
  int connect_string_length = 0 ;
  int gotdata = 0;
  int might_be_telnet = 1;

  /* For non-blocking */
  fd_set read_set ;
  struct timeval timeout ;

  timeout.tv_sec = TIMEOUT_SEC ;
  timeout.tv_usec = 0 ;

  /* 14: SIGALRM */
  signal(14, connectTimeout);            /* set-up signal handler */
  /* 
   * Currently available options:
   * -t <num> : seconds to wait for a timeout
   * -s <string> : string to use for the hello
   */

   while ( 1 )
   {
      i = getopt (argc, argv, "hVvt:s:");

      if (i == -1)
         break;

      switch (i)
      {
         case 'h':
            usage (argv[0]);
            exit (0);
            break ;

         case '?':
            usage (argv[0]);
            break ;

         case 't':
            timeout.tv_sec = atoi (optarg) ;

            if (timeout.tv_sec < 1 )
            {
               printf ("Timeout must be a positive integer\n");
               usage (argv[0]);
            }

            if (timeout.tv_sec > 30)
            {
#ifdef DEBUG
               printf ("Long timeout: %d seconds.\n", timeout.tv_sec);
#endif
            }
            break;

         case 'v':
         case 'V':
            printf ("bannergrab %s\n",VERSION);
            exit (0);
            break;
         case 's':
            gotdata = 1 ;
            connect_string_length = processString (optarg, &connect_string) ;
            break;
      }
   }

   if ( !connect_string_length )
   {
      connect_string_length = processString (TCP_CONNECT_STRING, &connect_string); 
   }

#ifdef DEBUG
   printf ("Connect String :\n%s\n---\n", connect_string) ;
#endif

   if(argc - optind !=2 ) 
      usage (argv[0]) ;

  SERVER_PORT = atoi(argv[optind +1]);

  if (SERVER_PORT < 1 || SERVER_PORT > 65535)
  {
    printf ("Enter a valid port number (1 - 65535)\n");
    usage (argv[0]);
  }

  h = gethostbyname(argv[optind]);
  if(h==NULL) {
    printf("%s: unknown host '%s'\n",argv[0],argv[1]);
    usage (argv[0]);
  }

  servAddr.sin_family = h->h_addrtype;
  memcpy((char *) &servAddr.sin_addr.s_addr, h->h_addr_list[0], h->h_length);
  servAddr.sin_port = htons(SERVER_PORT);

  /* create socket */
donotusegoto:

  tcp_socket = socket(AF_INET, SOCK_STREAM, 0);

  if(tcp_socket<0) {
    perror("Couldn't open socket ");
    exit(1);
  }

  /* bind any port number */
  localAddr.sin_family = AF_INET;
  localAddr.sin_addr.s_addr = htonl(INADDR_ANY);
  localAddr.sin_port = htons(0);
  
  result = bind(tcp_socket, (struct sockaddr *) &localAddr, sizeof(localAddr));
  if(result<0) {
    printf("%s: Couldn't bind to TCP port %u\n",argv[0],SERVER_PORT);
    perror("error ");
    exit(1);
  }

  /* Before connecting - check flags on socket and set O_NONBLOCK */
  {
      long one, two ;
      one = fcntl (tcp_socket, F_GETFL ) ;
#ifdef DEBUG
      printf ("%ld flags\n", one) ;
#endif
  }
  /* connect to server */
#ifdef DEBUG
     printf ("connecting\n");
#endif

     /* Set timeout for connect call */
     alarm (timeout.tv_sec) ;

  result = connect(tcp_socket, (struct sockaddr *) &servAddr, sizeof(servAddr));
     /* Cancel alarm call as connect succeeded */
     alarm (0) ;

  if(result<0) {
    perror("cannot connect ");
    exit(1);
  }

  /* Send the request packet.... */


#ifdef DEBUG
      printf ("sending data:\n");
      printPacket (connect_string, connect_string_length) ;
#endif
  result = send ( tcp_socket, connect_string, connect_string_length, 0);

  if (result != connect_string_length)
	  printf ("Only sent %d of %d bytes\n",result,connect_string_length);

  /* Wait for returned data */
  while (packet_count++ < MAX_PACKETS )
  {
     FD_ZERO (&read_set) ;
     FD_SET (tcp_socket, &read_set) ;

#ifdef DEBUG
     printf ("selecting %d\n", tcp_socket);
#endif
     select (tcp_socket + 1, &read_set, 0, 0, &timeout) ;
  
     if ( FD_ISSET ( tcp_socket, &read_set ))
     {
        result = recv (tcp_socket, buffer, BUFFER_SIZE, 0);
        buffer[result] = 0 ;

        if ( result > 0 )
        {
#ifdef DEBUG
           printf ("Got...\n");
#endif
           gotdata = 1 ;
           for ( i = 0; i < result; i++)
           {
              if ( buffer[i] < 32 || buffer[i] >= 127 )
              {
                /* don't use binary for tabs, newlines or carriage returns */
                if (buffer[i] == 10 || buffer[i] == 13 || buffer[i] == 9)
                  continue ;

                  printPacket (buffer, result) ;
#ifdef DEBUG
                printf ("because of %d\n", buffer[i]);
#endif
                break ;
              }
           }

           if ( i == result)
              printf("%s", buffer) ;

           if ( might_be_telnet)
           {
              /* Telnet negotiation */
              /* Reply contains DONT/WONT responses to requests */
              /* Check if response *is* telnet first... */
              int is_telnet = 1 ;

              for (i = 0;i < result; i=i+3)
                  is_telnet = is_telnet & (buffer[i] == 0xff) ;

              if (is_telnet)
              {
#ifdef DEBUG
                 printf ("*IS* telnet\n");
#endif
                 for (i = 1;i < result; i=i+3)
                 {
                     if (buffer[i] == 0xfd || buffer[i] == 0xfe)
                        buffer[i] = 0xfc ;
                     else if (buffer[i] == 0xfb || buffer[i] == 0xfc)
                        buffer[i] = 0xfe ;
                 }

#ifdef DEBUG
                 printf ("sending...\n");
                 printPacket (buffer, result);
#endif
                 result = send ( tcp_socket, buffer,result , 0);
              }
              else
                 might_be_telnet = 0;
           }
        }
        else
        {
#ifdef DEBUG
            printf ("no data\n");
#endif
        }
     }
     else
     {
       break ;
     }
  }

  if (!gotdata) 
  {
#ifdef DEBUG
      printf ("no data *AT*ALL* retrying with new connect string\n");
#endif
      close (tcp_socket) ;
      connect_string_length = processString (" ", &connect_string); 

      gotdata = 1 ; // protect against looping
      packet_count = 0;

      goto donotusegoto;
  }

  close (tcp_socket) ;

  printf("\n");

  return 0;
  
}


void printPacket (unsigned char* pkt, unsigned long size)
{
   int i,j, linel = 16 ;

   for (j =0; j < (size / linel +1);j ++ )
   {
      for (i=0; i< linel ; i++)
      {
         if ((j*linel + i) < size)
            printf ("%02x ", pkt[j*linel + i]) ;
         else
            printf ("   ") ;
      }
      printf ("  "); ;
      for (i=0; i< linel && (j*linel + i) < size ; i++)
      {
         if (pkt[j*linel + i] > 32 && pkt[j*linel + i] < 127)
            printf ("%c", pkt[j*linel + i]) ;
         else
            printf (".") ;
      }
      printf ("\n") ;

   }

   printf ("\n") ;
}

int getval (char char_in)
{
  if ( char_in >= 0x30 )
    if (char_in <= 0x39 )
      return char_in - 48 ;
    else
    {
      if (char_in > 0x60)
        char_in = char_in - 0x20 ;

      if (char_in >= 0x41)
        if (char_in <= 0x46)
          return char_in - 55 ;
    };

  return -1 ;
}

int processString (const char* string_in, char** string_out)
{
  int arg_length = strlen (string_in);
  int count, string_length = 0 ;
  (*string_out)=(char*)malloc (arg_length) ;

  for (count = 0; count < arg_length; count ++)
  {
    if (strncmp (string_in + count, "0x", 2) == 0)
    {
       int val1,val2 ;
       val1 = getval (string_in[count+2]) ;
       val2 = getval (string_in[count+3]) ;

       if (val1 >= 0 && val2 >= 0)
       {
               (*string_out)[string_length++] = val1*16+val2 ;
               count += 3 ;
       }
    }
    else
      (*string_out)[string_length++] = string_in[count];
  }
  (*string_out)[string_length] = 0 ;

  return string_length ;
}
